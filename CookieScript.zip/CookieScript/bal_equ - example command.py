# Example >:D
import sys
import CookieScript as ck
# CookieScript.bal_equ
# - Check if two inputs are equal
x = ("a")
y = ("b")
a = (ck.bal_equ(x, y))
if a == True:
    print("They're equal! :O")
else:
    print("Not equal... :/")
input()
sys.exit()