import CookieScript as cs, sys
# CookieScript.test
# - Tests if CookieScript is working
cs.test()
input()
sys.exit()