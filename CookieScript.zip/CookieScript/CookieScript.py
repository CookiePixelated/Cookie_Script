# COOKIE SCRIPT :D
# CODE \/ \/

def test():
    print("Cookie_Script tested successfully! :D")

def bal_equ(x,y):
    if x == y:
        return True
    else:
        return False